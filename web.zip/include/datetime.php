<?php
date_default_timezone_set("Africa/Nairobi");
$CurrentTime = new DateTime();
$DateTime = $CurrentTime->format('Y-m-d H:i:s');
?>
